#include "bcube_ops.h"
#include <iostream>
#include <atomic>
#include <thread>
#include <string>
#include <assert.h>
#include <cstring>
#include <algorithm>


extern int TYPE_SIZE[];

bcube_global_struct bcube_gs;
void bcube_do_steps(bcube_global_struct&);
void bg_loops(bcube_global_struct& bgs)
{

	bcube_init(bgs.bcube_s, bgs);
	bgs.unfinished_tensor.resize(4);
	bgs.is_inited_done = true;
	std::cout << "all init done, now we are going to send msg in bgthread..." << std::endl;
	while (true)
	{
		bcube_do_steps(bgs);
	}
}


/*
global init, launch a background thread.
*/

void bcube_all_init_onice(bcube_global_struct& gs)
{
	static int print_count = 0;
	if (!bcube_gs.bgthread_start.test_and_set())
	{
		std::cout << "start the bgthread" << std::endl;
		bcube_gs.bg_thread.push_back(std::thread(bg_loops, std::ref(bcube_gs)));
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}
	while (!bcube_gs.is_inited_done)
	{
		if ((print_count++) % 5 == 0)
			std::cout << "bcube is not inited successfully, waiting for other connecting" << std::endl;
		std::this_thread::sleep_for(std::chrono::seconds(1));
	}
}


bool bcube_reduce(bcube_global_struct& bgs, tensor_table_entry& e, bool is_scatter)
{
	auto tensor_name = e.tensor_name;
	std::vector<received_tensor_entry> rcv_tensor;
	{
		std::lock_guard<std::mutex> rece_lock(bgs.bcube_mutex);
		auto& tensor_receive = bgs.receiv_tensor;
		auto find_tensor = tensor_receive.find(tensor_name);
		if (find_tensor == tensor_receive.end())return false;/*not ready ,fetch it next*/
		rcv_tensor = std::move(find_tensor->second);
		tensor_receive.erase(find_tensor);
	}
	assert(rcv_tensor.size() == 4);

	if (e.tensor_ops == ALLREDUCE)
	{
		if (is_scatter)/*for scatter, sum these tensor*/
		{
			for (auto it = rcv_tensor.begin(); it != rcv_tensor.end(); it++)
			{
				auto tensor_ptr = (int*)it->receive_ptr;
				auto tensor_counts = it->tensor_nums;
				auto start_position = it->start_position;
				auto e_tensor_ptr = e.tensor_data;
				auto type_size = TYPE_SIZE[e.tensor_type];
				auto block_size = e.block_size;
				auto add_pos = (int*)((char*)e_tensor_ptr + start_position * type_size * block_size);
				for (size_t addnum = 0; addnum < tensor_counts; addnum++)
				{
					//printf("%d,%d,%d\n", add_pos[addnum], tensor_ptr[addnum], add_pos[addnum]+ tensor_ptr[addnum]);
					add_pos[addnum] += tensor_ptr[addnum];
				}
				{
					/*release reources*/
					std::free(it->receive_ptr);
					//printf("in allreduce: free %p\n", it->receive_ptr);
					it->receive_ptr = nullptr;
				}
			}
			return true;
		}
		else/*gather, replace these tensor*/
		{
			for (auto it = rcv_tensor.begin(); it != rcv_tensor.end(); it++)
			{
				auto tensor_ptr = (int*)it->receive_ptr;
				auto tensor_counts = it->tensor_nums;
				auto start_position = it->start_position;
				auto e_tensor_ptr = e.tensor_data;
				auto type_size = TYPE_SIZE[e.tensor_type];
				auto block_size = e.block_size;
				auto add_pos = (int*)((char*)e_tensor_ptr + start_position * type_size * block_size);
				for (size_t addnum = 0; addnum < tensor_counts; addnum++)
				{
					//printf("%d,%d,%d\n", add_pos[addnum], tensor_ptr[addnum], tensor_ptr[addnum]);
					add_pos[addnum] = tensor_ptr[addnum];
				}
				{
					/*release reources*/
					std::free(it->receive_ptr);
					//printf("in allreduce: free %p\n", it->receive_ptr);
					it->receive_ptr = nullptr;
				}
			}
			return true;
		}
	}
	else if (e.tensor_ops == ALLGATHER || e.tensor_ops == BROADCAST)
	{
		for (auto it = rcv_tensor.begin(); it != rcv_tensor.end(); it++)
		{
			for (size_t index = 0; index < it->gather_ptr.size(); index++)
			{
				auto& _a_tensor = e.gather_tensor[it->start_position + index];
				std::free(_a_tensor.tensor_ptr);
				//printf("in allgather reduce: free %p\n", _a_tensor.tensor_ptr);
				_a_tensor.tensor_ptr = it->gather_ptr[index].tensor_ptr;
				_a_tensor.tensor_shape = it->gather_ptr[index].tensor_shape;
			}
		}
	}
	return true;
}


void release_src(tensor_table_entry& e)
{
	std::vector<void*> free_ptr;
	free_ptr.push_back(e.tensor_data);
	free_ptr.push_back(nullptr);

	for (auto& it : e.gather_tensor)
	{
		if (find(free_ptr.begin(), free_ptr.end(), it.tensor_ptr) == free_ptr.end())
		{
			std::free(it.tensor_ptr);
			//printf("in release: free %p\n", it.tensor_ptr);
			free_ptr.push_back(it.tensor_ptr);
			it.tensor_ptr = nullptr;
		}
		else if (it.tensor_ptr != e.tensor_data)
		{
			perror("error in free data");
		}
	}
	std::free(e.tensor_data);
	//printf("in allreduce tensor data: free %p\n", e.tensor_data);
	e.tensor_data = nullptr;

	return;
}

static int reduce_loop = 0;
#define _DEBUG_TENSOR_GEN_
static void show_tensor(tensor_table_entry& e, int status = ALLREDUCE)
{
	int loops = 0;
	int node_id = 0;
	auto tensor_ptr = e.tensor_data;

#ifdef _DEBUG_TENSOR_GEN_
	if (e.tensor_ops == ALLREDUCE)
	{
		sscanf(e.tensor_name.c_str(), "_%d_allreduce_%d", &loops, &node_id);
		reduce_loop = loops;
		if ((loops % 100) || node_id != 100123)return;
	}
	else if (e.tensor_ops == ALLGATHER)
	{
		sscanf(e.tensor_name.c_str(), "_%d_allgather_%d", &loops, &node_id);
		reduce_loop = loops;
		if ((loops % 100) || node_id != 1003)return;
	}
	else if (e.tensor_ops == BROADCAST)
	{
		sscanf(e.tensor_name.c_str(), "_%d_broadcast_%d", &loops, &node_id);
		reduce_loop = loops;
		if ((loops % 100) || node_id != 1003)return;
	}
#endif // !_DEBUG_TENSOR_GEN_
	printf("%s ", e.tensor_name.c_str());
	if (e.tensor_ops == ALLREDUCE)
	{
		printf("[ ");
		for (int tensor_index = 0; tensor_index < e.tensor_size; tensor_index++)
			printf("%4d", ((int*)tensor_ptr)[tensor_index]);
		printf("]\n");
		if (0)
		{
			std::free(e.tensor_data);
			//printf("in allreduce: free %p\n", e.tensor_data);
			e.tensor_data = nullptr;
		}
	}
	else if (e.tensor_ops == ALLGATHER)
	{
		printf("\n[ ");
		for (int nums = 0; nums < 9; nums++)
		{
			auto& gather_tensor = e.gather_tensor[nums];
			auto& tensor_ptr = gather_tensor.tensor_ptr;
			printf("\n\t[");
			for (int tensor_index = 0; tensor_index < gather_tensor.tensor_shape; tensor_index++)
				printf("%4d", ((int*)tensor_ptr)[tensor_index]);
			printf("]\n");
		}
		printf("\n]\n");
	}
	else if (e.tensor_ops == BROADCAST)
	{
		printf("[ ");
		auto& broadcast_tensor = e.gather_tensor[0];
		auto& tensor_ptr = broadcast_tensor.tensor_ptr;
		for (int tensor_index = 0; tensor_index < broadcast_tensor.tensor_shape; tensor_index++)
			printf("%4d", ((int*)tensor_ptr)[tensor_index]);
		printf("]\n");
	}
	else
	{
		perror("not ready to handle");
		exit(-1);
	}
}
//void bcube_allreduce(char* src, char* dst, int block_size, int block_num, int block_type)
void bcube_do_steps(bcube_global_struct& bgs)
{
	auto& unfinished_vect = bgs.unfinished_tensor;
	auto unfin_size = (int)bgs.unfinished_tensor.size();
	//std::cout<<"unfinished tensor size: "<< unfin_size <<std::endl;
	{
		/*last stage*/
		std::vector<tensor_table_entry> tmp_tensor_table;
		auto& last_stage_tensor = unfinished_vect[unfin_size - 1];
		for (auto it = last_stage_tensor.begin(); it != last_stage_tensor.end(); it++)
		{
			if (bcube_reduce(bgs, *it, false))
			{
				/*in here done all the ops and execute a callback*/
				//std::cout<<"this tensor "<<it->tensor_name<<" is done..."<<std::endl;
				show_tensor(*it);
				release_src(*it);
			}
			else
			{
				tmp_tensor_table.push_back(std::move(*it));
			}
		}
		last_stage_tensor = std::move(tmp_tensor_table);
	}
	for (int unfin_index = unfin_size - 2; unfin_index >= 0; unfin_index--)
	{
		/*´Óstep3->step2->step1...step0*/
		std::vector<tensor_table_entry> tmp_tensor_table;
		auto& step_it = unfinished_vect[unfin_index];
		for (auto it = step_it.begin(); it != step_it.end(); it++)
		{
			bool is_reduce = bcube_reduce(bgs, *it, (unfin_index < (unfin_size / 2)) ? true : false);
			if (is_reduce)
			{
				/*copy to the next stage*/
				it->tensor_name += std::to_string(unfin_index + 1);
				bcube_send(*it, bgs.bcube_s, unfin_index + 1);
				//printf("...in the %d stage of %s...\n", unfin_index, it->tensor_name.c_str());
				unfinished_vect[unfin_index + 1].push_back(std::move(*it));
			}
			else
			{
				tmp_tensor_table.push_back(std::move(*it));
			}
		}
		step_it = std::move(tmp_tensor_table);
	}
	{
		/*from buf copy to unfinished.*/
		int count = 5;
		std::vector<tensor_table_entry> tmp_table;
		{
			std::lock_guard<std::mutex> gene_tensor_lock(bgs.bcube_mutex);
			auto & undo = bgs.tensor_table;
			while (!undo.empty() && count)
			{
				auto& it = undo.front();
				tmp_table.push_back(std::move(it));
				undo.pop();
			}
		}
		auto& unfin = bgs.unfinished_tensor;
		for (auto it = tmp_table.begin(); it != tmp_table.end(); it++)
		{
			it->tensor_name += "0";/*add exchange name*/
			if (it->tensor_ops == ALLREDUCE)
			{
				//printf("in allreduce\n");
				/*send out*/
				bcube_send((*it), bgs.bcube_s, 0);
				/*move to unfinished vector*/
				unfin[0].push_back(std::move(*it));
			}
			else if (it->tensor_ops == BROADCAST || it->tensor_ops == ALLGATHER)
			{
				/*enter a gather stage directly*/
				//printf("in allgather or broadcast, enter stage %d\n", unfin_size / 2);
				bcube_send((*it), bgs.bcube_s, unfin_size / 2);
				unfin[unfin_size / 2].push_back(std::move(*it));
			}
			else
			{
				std::cerr << "error in tensor..." << std::endl;
				exit(-1);
			}
		}
	}
}

#include <random>

void allreduce_enque(bcube_global_struct& bgs, int unique_id, int loops)
{
	std::random_device rd;
	int init_num = rd() % 83;
	int* a_ = new int[18]();
	for (int nums = 0; nums < 18; nums++)a_[nums] = init_num++;
	tensor_table_entry e;
	e.block_size = 1;
	e.tensor_name = "_" + std::to_string(loops) + "_allreduce_" + std::to_string(unique_id);
	e.available_nums = 18;
	e.tensor_size = 18;
	e.tensor_data = (void*)a_;
	e.tensor_type = T_INT32;
	e.tensor_ops = ALLREDUCE;
#ifdef _DEBUG_TENSOR_GEN_show_
	{
		std::lock_guard<std::mutex> print_tensor(bgs.bcube_mutex);
		printf("creates %s : [", e.tensor_name.c_str());
		for (int i = 0; i < 18; i++)printf("%5d", a_[i]);
		printf(" ]\n");
	}
#endif
	{
		std::lock_guard<std::mutex> enque_lock(bgs.bcube_mutex);
		auto& tensor_table = bgs.tensor_table;
		tensor_table.push(std::move(e));
	}
	while (bgs.tensor_table.size() > 100)
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	return;
}

void allgather_enqueue(bcube_global_struct& bgs, int unique_id, int loops)
{
	std::random_device rd;
	int init_num = rd() % 83;
	int* a_ = new int[18]();
	for (int nums = 0; nums < 18; nums++)a_[nums] = init_num++;
	tensor_table_entry e;
	e.block_size = 1;
	e.tensor_name = "_" + std::to_string(loops) + "_allgather_" + std::to_string(unique_id);
	e.available_nums = 18;
	e.tensor_size = 18;
	e.tensor_data = (void*)a_;
	e.gather_tensor.resize(e.tensor_size);
	{
		for (auto& it : e.gather_tensor)
		{
			it.tensor_shape = e.tensor_size;
			it.tensor_ptr = (void*)std::malloc(18 * sizeof(int));
			//printf("in allgather_enqueue: malloc %p\n", it.tensor_ptr);
			std::memcpy(it.tensor_ptr, (void*)a_, 18 * sizeof(int));
		}
	}
	e.tensor_type = T_INT32;
	e.tensor_ops = ALLGATHER;
	if (0)
	{
		std::lock_guard<std::mutex> print_tensor(bgs.bcube_mutex);
		printf("creates %s : [", e.tensor_name.c_str());
		for (int i = 0; i < 18; i++)printf("%5d", a_[i]);
		printf(" ]\n");
	}
	//e.tensor_ops = ALLREDUCE;
	//show_tensor(e,ALLGATHER);
	//e.tensor_ops = ALLGATHER;
	{
		std::lock_guard<std::mutex> enque_lock(bgs.bcube_mutex);
		auto& tensor_table = bgs.tensor_table;
		tensor_table.push(std::move(e));
	}
	while (bgs.tensor_table.size() > 100)
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	return;
}

void broadcast_enqueue(bcube_global_struct& bgs, int unique_id, int loops)
{
	std::random_device rd;
	int init_num = rd() % 83;
	int* a_ = new int[18]();
	for (int nums = 0; nums < 18; nums++)a_[nums] = init_num++;
	tensor_table_entry e;
	e.block_size = 1;
	e.tensor_name = "_" + std::to_string(loops) + "_broadcast_" + std::to_string(unique_id);
	e.available_nums = 18;
	e.tensor_size = 18;
	e.gather_tensor.resize(e.tensor_size);
	{
		for (auto& it : e.gather_tensor)
		{
			it.tensor_shape = e.tensor_size;
			it.tensor_ptr = (void*)std::malloc(18 * sizeof(int));
			//printf("in broadcast_enqueue: malloc %p\n", it.tensor_ptr);
			std::memcpy(it.tensor_ptr, (void*)a_, 18 * sizeof(int));
		}
	}
	e.tensor_data = (void*)a_;
	e.tensor_type = T_INT32;
	e.tensor_ops = BROADCAST;
	if (0)
	{
		std::lock_guard<std::mutex> print_tensor(bgs.bcube_mutex);
		printf("creates %s : [", e.tensor_name.c_str());
		for (int i = 0; i < 18; i++)printf("%5d", a_[i]);
		printf(" ]\n");
	}
	{
		std::lock_guard<std::mutex> enque_lock(bgs.bcube_mutex);
		auto& tensor_table = bgs.tensor_table;
		tensor_table.push(std::move(e));
	}
	while (bgs.tensor_table.size() > 100)
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	return;
}


// Copyright 2016 The TensorFlow Authors. All Rights Reserved.
// Modifications copyright (C) 2017 NEWPLAN Tsinghua University.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =============================================================================

#include <queue>
#include <thread>
#include <unordered_map>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/shape_inference.h"

#define EIGEN_USE_THREADS

#if HAVE_CUDA
#include "tensorflow/stream_executor/stream.h"
#include <cuda_runtime.h>
#endif


/*
 * Allreduce, Allgather and Broadcast Ops for TensorFlow.
 *
 * TensorFlow natively provides inter-device communication through send and
 * receive ops and inter-node communication through Distributed TensorFlow,
 * based on the same send and receive abstractions. These end up being
 * insufficient for synchronous data-parallel training on HPC clusters where
 * Infiniband or other high-speed interconnects are available.  This module
 * implements MPI ops for allgather, allreduce and broadcast, which do
 * optimized gathers, reductions and broadcasts and can take advantage of
 * hardware-optimized communication libraries through the MPI implementation.
 *
 * The primary logic of the allreduce, allgather and broadcast are in MPI and
 * NCCL implementations. The background thread which facilitates MPI operations
 * is run in BackgroundThreadLoop(). The provided ops are:
 *      - BcubeAllreduce:
 *          Perform an allreduce on a Tensor, returning the sum
 *          across all MPI processes in the global communicator.
 *      - BcubeAllgather:
 *          Perform an allgather on a Tensor, returning the concatenation of
 *          the tensor on the first dimension across all MPI processes in the
 *          global communicator.
 *      - BcubeBroadcast:
 *          Perform a broadcast on a Tensor, broadcasting Tensor
 *          value from root rank to all other ranks.
 *
 * Additionally, this library provides C APIs to initialize Bcube and query
 * rank, local rank and world size.  These are used in Python directly through
 * ctypes.
 */

using namespace tensorflow;

namespace bcube
{
namespace tensorflow
{

namespace
{

Status GetBCUBEDataType(const Tensor tensor, BCUBE_Datatype* dtype)
{
	switch (tensor.dtype())
	{
	case DT_UINT8:
		*dtype = MPI_UINT8_T;
		return Status::OK();
	case DT_INT8:
		*dtype = MPI_INT8_T;
		return Status::OK();
	case DT_UINT16:
		*dtype = MPI_UINT16_T;
		return Status::OK();
	case DT_INT16:
		*dtype = MPI_INT16_T;
		return Status::OK();
	case DT_INT32:
		*dtype = MPI_INT32_T;
		return Status::OK();
	case DT_INT64:
		*dtype = MPI_INT64_T;
		return Status::OK();
	case DT_FLOAT:
		*dtype = MPI_FLOAT;
		return Status::OK();
	case DT_DOUBLE:
		*dtype = MPI_DOUBLE;
		return Status::OK();
	case DT_BOOL:
		*dtype = MPI_C_BOOL;
		return Status::OK();
	default:
		// This is not reachable normally since we specify acceptable
		// data types in Op definition.
		return errors::Internal("Invalid tensor type.");
	}
}


#define MPI_CHECK(entries, op_name, op)                                        \
		  {                                                                            \
			auto mpi_result = (op);                                                    \
			if (mpi_result != MPI_SUCCESS) {                                           \
			  for (auto it = entries.begin(); it != entries.end(); it++) {             \
				timeline.End(it->tensor_name, nullptr);                                \
				it->callback(                                                          \
					errors::Unknown(op_name, " failed, see MPI output for details.")); \
			  }                                                                        \
			  return;                                                                  \
			}                                                                          \
		  }

#define CUDA_CHECK(entries, op_name, op)                                       \
		  {                                                                            \
			auto cuda_result = (op);                                                   \
			if (cuda_result != cudaSuccess) {                                          \
			  for (auto it = entries.begin(); it != entries.end(); it++) {             \
				timeline.End(it->tensor_name, nullptr);                                \
				it->callback(errors::Unknown(                                          \
					op_name, " failed: ", cudaGetErrorString(cuda_result)));           \
			  }                                                                        \
			  return;                                                                  \
			}                                                                          \
		  }

// Process an MPIResponse by doing a reduction, a gather, a broadcast, or
// raising an error.
void PerformOperation(TensorTable& tensor_table, MPIResponse response)
{
	/*´Ótensor±íÖÐÄÃµ½tensor£¬·ÅÈëÁÙÊ±µÄÄÚ´æÇø¿éÖÐ£¬±ãÓÚ¶à½ø³ÌµÄÐ­µ÷*/
	std::vector<TensorTableEntry> entries;
	{
		// Lock on the tensor table.
		std::lock_guard<std::mutex> guard(bcube_global.mutex);

		for (auto it = response.tensor_names().begin();
		        it != response.tensor_names().end(); it++)
		{
			// We should never fail at finding this key in the tensor table.
			auto name = *it;
			auto iter = tensor_table.find(name);
			assert(iter != tensor_table.end());

			assert(response.response_type() == MPIResponse::ALLREDUCE ||
			       response.response_type() == MPIResponse::ALLGATHER ||
			       response.response_type() == MPIResponse::BROADCAST ||
			       response.response_type() == MPIResponse::ERROR);

			entries.push_back(iter->second);

			// Clear the tensor table of this tensor and its callbacks; the rest of
			// this function takes care of it.
			tensor_table.erase(iter);
		}
	}

	/*µ÷ÊÔ£¬»­³öÊ±¼äÏß*/
	auto& timeline = bcube_global.timeline;
	for (auto it = entries.begin(); it != entries.end(); it++)
	{
		timeline.Start(it->tensor_name, response.response_type());
	}

	if (entries.size() > 1)
	{
		/*¶à¸ötensor*/
		auto first_entry = entries[0];
		auto& buffer = bcube_global.tensor_fusion_buffers[first_entry.device];
		if (buffer == nullptr)
		{
			ACTIVITY_START_ALL(entries, timeline, "INIT_FUSION_BUFFER")

			// Lazily allocate persistent buffer for Tensor Fusion and keep it
			// forever per device.
			TensorShape buffer_shape;
			buffer_shape.AddDim((int64)bcube_global.tensor_fusion_threshold);
			buffer = new PersistentTensor();
			Tensor* unused;
			Status status = first_entry.context->allocate_persistent(
			                    DT_INT8, buffer_shape, buffer, &unused);
			if (!status.ok())
			{
				for (auto it = entries.begin(); it != entries.end(); it++)
				{
					timeline.End(it->tensor_name, nullptr);
					it->callback(status);
				}
				return;
			}

#if HAVE_CUDA
			// On GPU allocation is asynchronous, we need to wait for it to
			// complete.
			auto device_context = first_entry.context->op_device_context();
			if (device_context != nullptr)
			{
				device_context->stream()->BlockHostUntilDone();
			}
#endif

			ACTIVITY_END_ALL(entries, timeline)
		}
	}

#if HAVE_CUDA
	// On GPU data readiness is signalled by ready_event.
	std::vector<TensorTableEntry> waiting_tensors;
	for (auto it = entries.begin(); it != entries.end(); it++)
	{
		if (it->ready_event != nullptr)
		{
			timeline.ActivityStart(it->tensor_name, "WAIT_FOR_DATA");
			waiting_tensors.push_back(*it);
		}
	}
	while (!waiting_tensors.empty())
	{
		for (auto it = waiting_tensors.begin(); it != waiting_tensors.end();)
		{
			if (it->ready_event->PollForStatus() !=
			        perftools::gputools::Event::Status::kPending)
			{
				timeline.ActivityEnd(it->tensor_name);
				timeline.ActivityStart(it->tensor_name, "WAIT_FOR_OTHER_TENSOR_DATA");
				it = waiting_tensors.erase(it);
			}
			else
			{
				it++;
			}
		}
		std::this_thread::sleep_for(std::chrono::nanoseconds(100));
	}
	for (auto it = entries.begin(); it != entries.end(); it++)
	{
		if (it->ready_event != nullptr)
		{
			timeline.ActivityEnd(it->tensor_name);
		}
	}
#endif

	Status status;
	if (response.response_type() == MPIResponse::ALLGATHER)
	{
		assert(entries.size() == 1);
		auto e = entries[0];

		// Copy tensor sizes from the MPI response into a vector of size_t
		// and compute total size.  This is size of first dimension.
		std::vector<size_t> tensor_sizes;
		size_t total_dimension_size = 0;
		for (auto it = response.tensor_sizes().begin();
		        it != response.tensor_sizes().end(); it++)
		{
			tensor_sizes.push_back(size_t(*it));
			total_dimension_size += size_t(*it);
		}

		// Every tensor participating in Allgather operation may have different
		// first dimension size, but the rest of dimensions are same for all
		// tensors.  Here we get shape of tensor sliced by first dimension.
		TensorShape single_slice_shape;
		for (int i = 1; i < e.tensor.shape().dims(); i++)
		{
			single_slice_shape.AddDim(e.tensor.dim_size(i));
		}

		// Allgather output will have shape of:
		// (sum of first dimension of every tensor) x (tensor slice shape).
		TensorShape output_shape;
		output_shape.AddDim((int64)total_dimension_size);
		output_shape.AppendShape(single_slice_shape);

		MPI_Datatype dtype;
		status = GetMPIDataType(e.tensor, &dtype);
		if (!status.ok())
		{
			timeline.End(e.tensor_name, nullptr);
			e.callback(status);
			return;
		}

		ACTIVITY_START_ALL(entries, timeline, "ALLOCATE_OUTPUT")
		status = e.context->allocate_output(0, output_shape, &e.output);
		if (!status.ok())
		{
			timeline.End(e.tensor_name, nullptr);
			e.callback(status);
			return;
		}

#if HAVE_CUDA
		// On GPU allocation is asynchronous, we need to wait for it to complete.
		auto device_context = e.context->op_device_context();
		if (device_context != nullptr)
		{
			device_context->stream()->BlockHostUntilDone();
		}
#endif
		ACTIVITY_END_ALL(entries, timeline)

		// Tensors may have different first dimension, so we need to use
		// MPI_Allgatherv API that supports gathering arrays of different length.
		ACTIVITY_START_ALL(entries, timeline, "MPI_ALLGATHER")
		int* recvcounts = new int[tensor_sizes.size()];
		int* displcmnts = new int[tensor_sizes.size()];
		for (size_t i = 0; i < tensor_sizes.size(); i++)
		{
			recvcounts[i] =
			    (int)(single_slice_shape.num_elements() * tensor_sizes[i]);
			if (i == 0)
			{
				displcmnts[i] = 0;
			}
			else
			{
				displcmnts[i] = recvcounts[i - 1] + displcmnts[i - 1];
			}
		}
		auto result = MPI_Allgatherv((const void*)e.tensor.tensor_data().data(),
		                             (int)e.tensor.NumElements(), dtype,
		                             (void*)e.output->tensor_data().data(),
		                             recvcounts, displcmnts, dtype, MPI_COMM_WORLD);
		delete[] recvcounts;
		delete[] displcmnts;
		MPI_CHECK(entries, "MPI_Allgatherv", result)
		ACTIVITY_END_ALL(entries, timeline)

		timeline.End(e.tensor_name, e.output);
		e.callback(Status::OK());

	}
	else if (response.response_type() == MPIResponse::ALLREDUCE)
	{
		auto first_entry = entries[0];
#if HAVE_CUDA
		bool on_gpu = first_entry.device != CPU_DEVICE_ID;
		if (on_gpu)
		{
			CUDA_CHECK(entries, "cudaSetDevice", cudaSetDevice(first_entry.device))

			// Ensure stream is in the map before executing reduction.
			cudaStream_t& stream = bcube_global.streams[first_entry.device];
			if (stream == nullptr)
			{
				CUDA_CHECK(entries, "cudaStreamCreate", cudaStreamCreate(&stream))
			}
		}
#endif


		MPI_Datatype dtype;
		status = GetMPIDataType(first_entry.tensor, &dtype);
		if (!status.ok())
		{
			for (auto it = entries.begin(); it != entries.end(); it++)
			{
				timeline.End(it->tensor_name, nullptr);
				it->callback(status);
			}
			return;
		}

		if (entries.size() > 1)
		{
			// Access the fusion buffer.
			auto buffer_data =
			    bcube_global.tensor_fusion_buffers[first_entry.device]
			    ->AccessTensor(first_entry.context)
			    ->tensor_data()
			    .data();

			// Copy memory into the fusion buffer.
			ACTIVITY_START_ALL(entries, timeline, "MEMCPY_IN_FUSION_BUFFER")
			size_t offset = 0;
			for (auto it = entries.begin(); it != entries.end(); it++)
			{
#if HAVE_CUDA
				if (on_gpu)
				{
					CUDA_CHECK(
					    entries, "cudaMemcpyAsync",
					    cudaMemcpyAsync((void*)(buffer_data + offset),
					                    (const void*)it->tensor.tensor_data().data(),
					                    it->tensor.tensor_data().size(),
					                    cudaMemcpyDeviceToDevice,
					                    bcube_global.streams[first_entry.device]))
				}
				else
				{
#endif
					memcpy((void*)(buffer_data + offset),
					       (const void*)it->tensor.tensor_data().data(),
					       it->tensor.tensor_data().size());
#if HAVE_CUDA
				}
#endif
				offset += it->tensor.tensor_data().size();
			}
#if HAVE_CUDA
			if (on_gpu)
			{
				CUDA_CHECK(
				    entries, "cudaStreamSynchronize",
				    cudaStreamSynchronize(bcube_global.streams[first_entry.device]))
			}
#endif
			ACTIVITY_END_ALL(entries, timeline)

			ACTIVITY_START_ALL(entries, timeline, "MPI_ALLREDUCE")
			size_t num_elements = 0;
			for (auto it = entries.begin(); it != entries.end(); it++)
			{
				num_elements += it->tensor.NumElements();
			}
			MPI_CHECK(entries, "MPI_Allreduce",
			          MPI_Allreduce(MPI_IN_PLACE, (void*)buffer_data,
			                        (int)num_elements, dtype, MPI_SUM,
			                        MPI_COMM_WORLD))
			ACTIVITY_END_ALL(entries, timeline)

			// Copy memory out of the fusion buffer.
			ACTIVITY_START_ALL(entries, timeline, "MEMCPY_OUT_FUSION_BUFFER")
			offset = 0;
			for (auto it = entries.begin(); it != entries.end(); it++)
			{
#if HAVE_CUDA
				if (on_gpu)
				{
					CUDA_CHECK(
					    entries, "cudaMemcpyAsync",
					    cudaMemcpyAsync((void*)it->output->tensor_data().data(),
					                    (const void*)(buffer_data + offset),
					                    it->tensor.tensor_data().size(),
					                    cudaMemcpyDeviceToDevice,
					                    bcube_global.streams[first_entry.device]))
				}
				else
				{
#endif
					memcpy((void*)it->output->tensor_data().data(),
					       (const void*)(buffer_data + offset),
					       it->tensor.tensor_data().size());
#if HAVE_CUDA
				}
#endif
				offset += it->tensor.tensor_data().size();
			}
#if HAVE_CUDA
			if (on_gpu)
			{
				CUDA_CHECK(
				    entries, "cudaStreamSynchronize",
				    cudaStreamSynchronize(bcube_global.streams[first_entry.device]))
			}
#endif
			ACTIVITY_END_ALL(entries, timeline)
		}
		else
		{
			auto e = first_entry;
			ACTIVITY_START_ALL(entries, timeline, "MPI_ALLREDUCE")
			MPI_CHECK(entries, "MPI_Allreduce",
			          MPI_Allreduce((const void*)e.tensor.tensor_data().data(),
			                        (void*)e.output->tensor_data().data(),
			                        (int)e.tensor.NumElements(), dtype, MPI_SUM,
			                        MPI_COMM_WORLD))
			ACTIVITY_END_ALL(entries, timeline)
		}

		for (auto it = entries.begin(); it != entries.end(); it++)
		{
			timeline.End(it->tensor_name, it->output);
			it->callback(Status::OK());
		}
	}
	else if (response.response_type() == MPIResponse::BROADCAST)
	{
		assert(entries.size() == 1);
		auto e = entries[0];

		MPI_Datatype dtype;
		status = GetMPIDataType(e.tensor, &dtype);
		if (!status.ok())
		{
			timeline.End(e.tensor_name, nullptr);
			e.callback(status);
			return;
		}

		// On root rank, MPI_Bcast sends data, on other ranks it receives data.
		void* data_ptr;
		if (bcube_global.rank == e.root_rank)
		{
			data_ptr = (void*)e.tensor.tensor_data().data();
		}
		else
		{
			data_ptr = (void*)e.output->tensor_data().data();
		}

		ACTIVITY_START_ALL(entries, timeline, "MPI_BCAST")
		MPI_CHECK(entries, "MPI_Bcast",
		          MPI_Bcast(data_ptr, (int)e.tensor.NumElements(), dtype,
		                    e.root_rank, MPI_COMM_WORLD))
		ACTIVITY_END_ALL(entries, timeline)

		timeline.End(e.tensor_name, e.output);
		e.callback(Status::OK());
	}
	else if (response.response_type() == MPIResponse::ERROR)
	{
		assert(entries.size() == 1);
		auto e = entries[0];

		status = errors::FailedPrecondition(response.error_message());
		timeline.End(e.tensor_name, nullptr);
		e.callback(status);
	}
}

// Report Tensors that were submitted to be reduced, gathered or broadcasted by
// some ranks but not others and are waiting for long time to get processed.
void CheckForStalledTensors(BcubeGlobalState& state)
{
	bool preamble = false;
	auto now = std::chrono::steady_clock::now();
	for (auto it = state.message_table->begin(); it != state.message_table->end();
	        it++)
	{
		auto tensor_name = it->first;
		std::vector<MPIRequest>& messages = std::get<0>(it->second);
		std::chrono::steady_clock::time_point start_at = std::get<1>(it->second);

		if (now - start_at > STALL_WARNING_TIME)
		{
			if (!preamble)
			{
				std::cerr << "WARNING: One or more tensors were submitted to be "
				          "reduced, gathered or broadcasted by subset of ranks and "
				          "are waiting for remainder of ranks for more than "
				          << std::chrono::duration_cast<std::chrono::seconds>(
				              STALL_WARNING_TIME)
				          .count()
				          << " seconds. ";
				std::cerr << "This may indicate that different ranks are trying to "
				          "submit different tensors or that only subset of ranks is "
				          "submitting tensors, which will cause deadlock. ";
				std::cerr << "Stalled ops: ";
				preamble = true;
			}
			else
			{
				std::cerr << ", ";
			}
			std::cerr << tensor_name;
			std::cerr << " [ready ranks:";
			for (auto msg_iter = messages.begin(); msg_iter != messages.end();
			        msg_iter++)
			{
				if (msg_iter == messages.begin())
				{
					std::cerr << " ";
				}
				else
				{
					std::cerr << ", ";
				}
				std::cerr << msg_iter->request_rank();
			}
			std::cerr << "]";
		}
	}
	if (preamble)
	{
		std::cerr << std::endl;
	}
}

// The MPI background thread loop coordinates all the MPI processes and the
// tensor reductions. The design of the communicator mechanism is limited by a
// few considerations:
//
//      1. Some MPI implementations require all MPI calls to happen from a
//      single thread. Since TensorFlow may use several threads for graph
//      processing, this means we must have our own dedicated thread for dealing
//      with MPI.
//      2. We want to gracefully handle errors, when MPI processes do not
//      properly agree upon what should happen (such as mismatched types or
//      shapes). To do so requires the MPI processes to know about the shapes
//      and types of the relevant tensors on the other processes.
//      3. The MPI reductions and gathers should be able to happen in parallel
//      with other ongoing operations. This means that they cannot be blocking
//      ops, but rather must be async ops, the execution of which happens on a
//      separate thread.
//      4. We cannot guarantee that all the MPI processes reduce their tensors
//      in the same order, so we cannot dispatch one thread per tensor,
//      otherwise we may end up dispatching many blocked threads and never make
//      progress if we have a thread pool limit.
//
// The coordinator currently follows a master-worker paradigm. Rank zero acts
// as the master (the "coordinator"), whereas all other ranks are simply
// workers. Each rank runs its own background thread which progresses in ticks.
// In each tick, the following actions happen:
//
//      a) The workers send an MPIRequest to the coordinator, indicating what
//      they would like to do (which tensor they would like to gather and
//      reduce, as well as their shape and type). They repeat this for every
//      tensor that they would like to operate on.
//
//      b) The workers send an empty "DONE" message to the coordinator to
//      indicate that there are no more tensors they wish to operate on.
//
//      c) The coordinator receives the MPIRequests from the workers, as well
//      as from its own TensorFlow ops, and stores them in a request table. The
//      coordinator continues to receive MPIRequest messages until it has
//      received MPI_SIZE number of empty "DONE" messages.
//
//      d) The coordinator finds all tensors that are ready to be reduced,
//      gathered, or all operations that result in an error. For each of those,
//      it sends an MPIResponse to all the workers. When no more MPIResponses
//      are available, it sends a "DONE" response to the workers. If the process
//      is being shutdown, it instead sends a "SHUTDOWN" response.
//
//      e) The workers listen for MPIResponse messages, processing each one by
//      doing the required reduce or gather, until they receive a "DONE"
//      response from the coordinator. At that point, the tick ends.
//      If instead of "DONE" they receive "SHUTDOWN", they exit their background
//      loop.
void BackgroundThreadLoop(BcubeGlobalState& state)
{
	// Initialize MPI. This must happen on the background thread, since not all
	// MPI implementations support being called from multiple threads.
	MPI_Init(NULL, NULL);

	// Get MPI rank to determine if we are rank zero.
	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	bool is_coordinator = rank == 0;

	// Get MPI size to determine how many tensors to wait for before reducing.
	int size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	// Determine local rank by querying the local communicator.
	MPI_Comm local_comm;
	MPI_Comm_split_type(MPI_COMM_WORLD, MPI_COMM_TYPE_SHARED, 0, MPI_INFO_NULL,
	                    &local_comm);
	int local_rank;
	MPI_Comm_rank(local_comm, &local_rank);

	state.rank = rank;
	state.local_rank = local_rank;
	state.size = size;
	state.initialization_done = true;

	// Open the timeline file on coordinator.
	auto bcube_timeline = std::getenv("BCUBE_TIMELINE");
	if (is_coordinator && bcube_timeline != nullptr)
	{
		state.timeline.Initialize(std::string(bcube_timeline));
	}

	// Override Tensor Fusion threshold, if it's set.
	auto bcube_fusion_threshold = std::getenv("BCUBE_FUSION_THRESHOLD");
	if (bcube_fusion_threshold != nullptr)
	{
		state.tensor_fusion_threshold = size_t(std::atol(bcube_fusion_threshold));
	}

	// Initialize the tensor count table. No tensors are available yet.
	if (is_coordinator)
	{
		state.message_table = std::unique_ptr<MessageTable>(new MessageTable());
	}

	// The coordinator sends a SHUTDOWN message to trigger shutdown.
	bool should_shut_down = false;
	do
	{
		// This delay determines thread frequency and MPI message latency
		std::this_thread::sleep_for(std::chrono::milliseconds(5));

		// Copy the data structures from global state under this lock.
		// However, don't keep the lock for the rest of the loop, so that
		// enqueued stream callbacks can continue.
		std::queue<MPIRequest> message_queue;
		{
			std::lock_guard<std::mutex> guard(state.mutex);
			while (!state.message_queue.empty())
			{
				MPIRequest message = state.message_queue.front();
				state.message_queue.pop();
				message_queue.push(message);
			}
		}

		// Collect all tensors that are ready to be reduced. Record them in the
		// tensor count table (rank zero) or send them to rank zero to be
		// recorded (everyone else).
		std::vector<std::string> ready_to_reduce;
		while (!message_queue.empty())
		{
			// Pop the first available message message
			MPIRequest message = message_queue.front();
			message_queue.pop();

			if (is_coordinator)
			{
				bool reduce = IncrementTensorCount(state.message_table, message, size);
				if (reduce)
				{
					ready_to_reduce.push_back(message.tensor_name());
				}
			}
			else
			{
				std::string encoded_message;
				MPIRequest::SerializeToString(message, encoded_message);
				MPI_Send(encoded_message.c_str(), (int)encoded_message.length() + 1,
				         MPI_BYTE, RANK_ZERO, TAG_NOTIFY, MPI_COMM_WORLD);
			}
		}

		// Rank zero has put all its own tensors in the tensor count table.
		// Now, it should count all the tensors that are coming from other
		// ranks at this tick. It should keep getting tensors until it gets a
		// DONE message from all the other ranks.
		if (is_coordinator)
		{
			// Count of DONE messages. Keep receiving messages until the number
			// of messages is equal to the number of processes. Initialize to
			// one since the coordinator is effectively done.
			int completed_ranks = 1;
			while (completed_ranks != size)
			{
				MPI_Status status;
				MPI_Probe(MPI_ANY_SOURCE, TAG_NOTIFY, MPI_COMM_WORLD, &status);

				// Find number of characters in message (including zero byte).
				int source_rank = status.MPI_SOURCE;
				int msg_length;
				MPI_Get_count(&status, MPI_BYTE, &msg_length);

				// If the length is zero, this is a DONE message.
				if (msg_length == 0)
				{
					completed_ranks++;
					MPI_Recv(NULL, 0, MPI_BYTE, source_rank, TAG_NOTIFY, MPI_COMM_WORLD,
					         &status);
					continue;
				}

				// Get tensor name from MPI into an std::string.
				char* buffer = new char[msg_length];
				MPI_Recv(buffer, msg_length, MPI_BYTE, source_rank, TAG_NOTIFY,
				         MPI_COMM_WORLD, &status);
				std::string received_data(buffer, (size_t)msg_length);
				delete[] buffer;

				MPIRequest received_message;
				MPIRequest::ParseFromString(received_message, received_data);
				auto received_name = received_message.tensor_name();

				bool reduce =
				    IncrementTensorCount(state.message_table, received_message, size);
				if (reduce)
				{
					ready_to_reduce.push_back(received_name);
				}
			}

			// At this point, rank zero should have a fully updated tensor count
			// table and should know all the tensors that need to be reduced or
			// gathered, and everyone else should have sent all their information
			// to rank zero. We can now do reductions and gathers; rank zero will
			// choose which ones and in what order, and will notify the other ranks
			// before doing each reduction.
			std::vector<MPIResponse> responses;
			for (auto it = ready_to_reduce.begin(); it != ready_to_reduce.end();
			        it++)
			{
				MPIResponse response = ConstructMPIResponse(state.message_table, *it);
				responses.push_back(std::move(response));
			}

			while (!responses.empty())
			{
				auto it = responses.begin();
				MPIResponse response = *it;
				assert(response.tensor_names().size() == 1);
				it = responses.erase(it);

				if (response.response_type() == MPIResponse::ResponseType::ALLREDUCE)
				{
					// Attempt to add more responses to this fused response.
					auto& entry = state.tensor_table[response.tensor_names()[0]];
					size_t tensor_size = entry.tensor.tensor_data().size();

					while (it != responses.end())
					{
						assert(it->tensor_names().size() == 1);
						auto& new_entry = state.tensor_table[it->tensor_names()[0]];
						size_t new_tensor_size = new_entry.tensor.tensor_data().size();

						if (response.response_type() == it->response_type() &&
						        response.devices() == it->devices() &&
						        entry.tensor.dtype() == new_entry.tensor.dtype() &&
						        tensor_size + new_tensor_size <=
						        state.tensor_fusion_threshold)
						{
							// These tensors will fuse together well.
							tensor_size += new_tensor_size;
							response.add_tensor_names(it->tensor_names()[0]);
							it = responses.erase(it);
						}
						else
						{
							// Don't try to fuse additional tensors since they are usually
							// computed in order of requests and skipping tensors may mean
							// that the batch will have to wait longer while skipped tensors
							// could be reduced at that time.
							break;
						}
					}
				}

				// Notify all nodes which tensors we'd like to reduce at this step.
				std::string encoded_response;
				MPIResponse::SerializeToString(response, encoded_response);
				for (int r = 1; r < size; r++)
				{
					MPI_Send(encoded_response.c_str(), (int)encoded_response.length() + 1,
					         MPI_BYTE, r, TAG_NOTIFY, MPI_COMM_WORLD);
				}

				// Perform the collective operation. All nodes should end up performing
				// the same operation.
				PerformOperation(state.tensor_table, response);
			}

			// Notify all nodes that we are done with the reductions for this tick.
			MPIResponse done_response;
			should_shut_down = state.shut_down;
			done_response.set_response_type(should_shut_down ? MPIResponse::SHUTDOWN
			                                : MPIResponse::DONE);
			std::string encoded_response;
			MPIResponse::SerializeToString(done_response, encoded_response);
			for (int r = 1; r < size; r++)
			{
				MPI_Send(encoded_response.c_str(), (int)encoded_response.length() + 1,
				         MPI_BYTE, r, TAG_NOTIFY, MPI_COMM_WORLD);
			}

			// Check for stalled tensors.
			if (std::chrono::steady_clock::now() - state.last_stall_check >
			        STALL_WARNING_TIME)
			{
				CheckForStalledTensors(state);
				state.last_stall_check = std::chrono::steady_clock::now();
			}
		}
		else
		{
			// Notify the coordinator that this node is done sending messages.
			// A DONE message is encoded as a zero-length message.
			MPI_Send(NULL, 0, MPI_BYTE, RANK_ZERO, TAG_NOTIFY, MPI_COMM_WORLD);

			// Receive names for tensors to reduce from rank zero.
			// Once we receive a empty DONE message, stop waiting for more names.
			while (true)
			{
				MPI_Status status;
				MPI_Probe(0, TAG_NOTIFY, MPI_COMM_WORLD, &status);

				// Find number of characters in message (including zero byte).
				int msg_length;
				MPI_Get_count(&status, MPI_BYTE, &msg_length);

				// Get tensor name from MPI into an std::string.
				char* buffer = new char[msg_length];
				MPI_Recv(buffer, msg_length, MPI_BYTE, 0, TAG_NOTIFY, MPI_COMM_WORLD,
				         &status);
				std::string received_message(buffer, (size_t)msg_length);
				delete[] buffer;

				MPIResponse response;
				MPIResponse::ParseFromString(response, received_message);
				if (response.response_type() == MPIResponse::DONE)
				{
					// No more messages this tick
					break;
				}
				else if (response.response_type() == MPIResponse::SHUTDOWN)
				{
					// No more messages this tick, and the background thread should shut
					// down
					should_shut_down = true;
					break;
				}
				else
				{
					// Process the current message
					PerformOperation(state.tensor_table, response);
				}
			}
		}
	}
	while (!should_shut_down);

	for (auto it = state.tensor_fusion_buffers.begin();
	        it != state.tensor_fusion_buffers.end(); it++)
	{
		delete it->second;
	}

	// TODO: init.cu:645 WARN Cuda failure 'driver shutting down'
	//#if HAVE_NCCL
	//  for (auto it = bcube_global.streams.begin();
	//       it != bcube_global.streams.end(); it++) {
	//    cudaStreamSynchronize(it->second);
	//  }
	//  for (auto it = bcube_global.nccl_comms.begin();
	//       it != bcube_global.nccl_comms.end(); it++) {
	//    ncclCommDestroy(it->second);
	//  }
	//#endif
	MPI_Finalize();
}

// Check that Bcube is initialized.
Status CheckInitialized()
{
	if (!bcube_gs.is_inited_done)
	{
		return errors::FailedPrecondition(
		           "Bcube has not been initialized; use bcube.tensorflow.init().");
	}
	return Status::OK();
}

// C interface to initialize Bcube.
extern "C" void bcube_tensorflow_init()
{
	bcube_all_init_onice(bcube_gs);
}

// C interface to get index of current Bcube process.
// Returns -1 if Bcube is not initialized.
extern "C" int bcube_tensorflow_rank()
{
	if (!bcube_gs.is_inited_done)
	{
		return -1;
	}
	return bcube_gs.bcube_s.rank;
}

// C interface to get index of current Bcube process in the node it is on..
// Returns -1 if Bcube is not initialized.
extern "C" int bcube_tensorflow_local_rank()
{
	return 0;
}

// C interface to return number of Bcube processes.
// Returns -1 if Bcube is not initialized.
extern "C" int bcube_tensorflow_size()
{
	if (!bcube_gs.is_inited_done)
	{
		return -1;
	}
	return bcube_gs.bcube_s.bcube_node_count;
}

// Convert a TensorFlow DataType to our MPIDataType.
Status DataTypeToBcubeType(DataType tf_dtype, BCUBE_TYPE* bcube_dtype)
{
	switch (tf_dtype)
	{
	case DT_UINT8:
		*bcube_dtype = T_UINIT8;
		return Status::OK();
	case DT_INT8:
		*bcube_dtype = T_INIT8;
		return Status::OK();
	case DT_UINT16:
		*bcube_dtype = T_UINT16;
		return Status::OK();
	case DT_INT16:
		*bcube_dtype = T_INT16;
		return Status::OK();
	case DT_INT32:
		*bcube_dtype = T_INT32;
		return Status::OK();
	case DT_INT64:
		*bcube_dtype = T_INT64;
		return Status::OK();
	case DT_FLOAT:
		*bcube_dtype = T_FLOAT32;
		return Status::OK();
	case DT_DOUBLE:
		*bcube_dtype = T_FLOAT64;
		return Status::OK();
	case DT_BOOL:
		*bcube_dtype = T_BOOL;
		return Status::OK();
	default:
		return errors::Internal("Invalid tensor type.");
	}
}
void allreduce_enque(OpKernelContext* context, const Tensor& tensor,
                     Tensor* output, GPU_EVENT_IF_CUDA ready_event,
                     const std::string name, const int device,
                     StatusCallback callback)
{
	auto &bgs = bcube_gs;

	BCUBE_TYPE dtype;
	Status status = DataTypeToBcubeType(tensor.dtype(), &dtype);
	if (!status.ok())
	{
		callback(status);
		return;
	}
	std::vector<int64_t> a_shape;
	for (int i = 0; i < tensor.shape().dims(); i++)
	{
		a_shape.pushback(tensor.shape().dim_size(i));
	}
	tensor_table_entry e;
	e.tensor = tensor;
	e.output = output;
	e.context = context;
	e.ready_event = ready_event;

	e.device = device;
	e.callback = callback;



	{
		std::lock_guard<std::mutex> enque_lock(bgs.bcube_mutex);
		auto& tensor_table = bgs.tensor_table;
		tensor_table.push(std::move(e));
	}

	std::random_device rd;
	int init_num = rd() % 83;
	int* a_ = new int[18]();
	for (int nums = 0; nums < 18; nums++)a_[nums] = init_num++;
	tensor_table_entry e;
	e.block_size = 1;
	e.tensor_name = "_" + std::to_string(loops) + "_allreduce_" + std::to_string(unique_id);
	e.available_nums = 18;
	e.tensor_size = 18;
	e.tensor_data = (void*)a_;
	e.tensor_type = T_INT32;
	e.tensor_ops = ALLREDUCE;
#ifdef _DEBUG_TENSOR_GEN_show_
	{
		std::lock_guard<std::mutex> print_tensor(bgs.bcube_mutex);
		printf("creates %s : [", e.tensor_name.c_str());
		for (int i = 0; i < 18; i++)printf("%5d", a_[i]);
		printf(" ]\n");
	}
#endif
	{
		std::lock_guard<std::mutex> enque_lock(bgs.bcube_mutex);
		auto& tensor_table = bgs.tensor_table;
		tensor_table.push(std::move(e));
	}
	while (bgs.tensor_table.size() > 100)
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	return;
}

void allgather_enqueue(bcube_global_struct& bgs, int unique_id, int loops)
{
	std::random_device rd;
	int init_num = rd() % 83;
	int* a_ = new int[18]();
	for (int nums = 0; nums < 18; nums++)a_[nums] = init_num++;
	tensor_table_entry e;
	e.block_size = 1;
	e.tensor_name = "_" + std::to_string(loops) + "_allgather_" + std::to_string(unique_id);
	e.available_nums = 18;
	e.tensor_size = 18;
	e.tensor_data = (void*)a_;
	e.gather_tensor.resize(e.tensor_size);
	{
		for (auto& it : e.gather_tensor)
		{
			it.tensor_shape = e.tensor_size;
			it.tensor_ptr = (void*)std::malloc(18 * sizeof(int));
			//printf("in allgather_enqueue: malloc %p\n", it.tensor_ptr);
			std::memcpy(it.tensor_ptr, (void*)a_, 18 * sizeof(int));
		}
	}
	e.tensor_type = T_INT32;
	e.tensor_ops = ALLGATHER;
	if (0)
	{
		std::lock_guard<std::mutex> print_tensor(bgs.bcube_mutex);
		printf("creates %s : [", e.tensor_name.c_str());
		for (int i = 0; i < 18; i++)printf("%5d", a_[i]);
		printf(" ]\n");
	}
	//e.tensor_ops = ALLREDUCE;
	//show_tensor(e,ALLGATHER);
	//e.tensor_ops = ALLGATHER;
	{
		std::lock_guard<std::mutex> enque_lock(bgs.bcube_mutex);
		auto& tensor_table = bgs.tensor_table;
		tensor_table.push(std::move(e));
	}
	while (bgs.tensor_table.size() > 100)
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	return;
}

void broadcast_enqueue(bcube_global_struct& bgs, int unique_id, int loops)
{
	std::random_device rd;
	int init_num = rd() % 83;
	int* a_ = new int[18]();
	for (int nums = 0; nums < 18; nums++)a_[nums] = init_num++;
	tensor_table_entry e;
	e.block_size = 1;
	e.tensor_name = "_" + std::to_string(loops) + "_broadcast_" + std::to_string(unique_id);
	e.available_nums = 18;
	e.tensor_size = 18;
	e.gather_tensor.resize(e.tensor_size);
	{
		for (auto& it : e.gather_tensor)
		{
			it.tensor_shape = e.tensor_size;
			it.tensor_ptr = (void*)std::malloc(18 * sizeof(int));
			//printf("in broadcast_enqueue: malloc %p\n", it.tensor_ptr);
			std::memcpy(it.tensor_ptr, (void*)a_, 18 * sizeof(int));
		}
	}
	e.tensor_data = (void*)a_;
	e.tensor_type = T_INT32;
	e.tensor_ops = BROADCAST;
	if (0)
	{
		std::lock_guard<std::mutex> print_tensor(bgs.bcube_mutex);
		printf("creates %s : [", e.tensor_name.c_str());
		for (int i = 0; i < 18; i++)printf("%5d", a_[i]);
		printf(" ]\n");
	}
	{
		std::lock_guard<std::mutex> enque_lock(bgs.bcube_mutex);
		auto& tensor_table = bgs.tensor_table;
		tensor_table.push(std::move(e));
	}
	while (bgs.tensor_table.size() > 100)
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	return;
}
// MPI must be initialized and the background thread must be running before
// this function is called.
void EnqueueTensorAllreduce(OpKernelContext* context, const Tensor& tensor,
                            Tensor* output, GPU_EVENT_IF_CUDA ready_event,
                            const std::string name, const int device,
                            StatusCallback callback)
{
	BCUBE_TYPE dtype;
	Status status = DataTypeToBcubeType(tensor.dtype(), &dtype);
	if (!status.ok())
	{
		callback(status);
		return;
	}

	std::vector<int64_t> a_shape;
	for (int i = 0; i < tensor.shape().dims(); i++)
	{
		a_shape.pushback(tensor.shape().dim_size(i));
	}

	tensor_table_entry e;
	e.tensor_name = name;

	e.context = context;
	e.tensor = tensor;
	e.output = output;
	e.ready_event = ready_event;
	e.device = device;
	e.callback = callback;

	std::lock_guard<std::mutex> guard(bcube_gs.bcube_mutex);
	bcube_gs.tensor_table.emplace(name, std::move(e));
	bcube_global.message_queue.push(message);
}

// MPI must be initialized and the background thread must be running before
// this function is called.
void EnqueueTensorAllgather(OpKernelContext* context, const Tensor& tensor,
                            GPU_EVENT_IF_CUDA ready_event,
                            const std::string name, const int device,
                            StatusCallback callback)
{
	MPIDataType dtype;
	Status status = DataTypeToBcubeType(tensor.dtype(), &dtype);
	if (!status.ok())
	{
		callback(status);
		return;
	}

	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	MPIRequest message;
	message.set_request_rank(rank);
	message.set_tensor_name(name);
	message.set_tensor_type(dtype);
	message.set_device(device);
	message.set_request_type(MPIRequest::ALLGATHER);
	for (int i = 0; i < tensor.shape().dims(); i++)
	{
		message.add_tensor_shape(tensor.shape().dim_size(i));
	}

	TensorTableEntry e;
	e.tensor_name = name;
	e.context = context;
	e.tensor = tensor;
	e.ready_event = ready_event;
	e.device = device;
	e.callback = callback;

	std::lock_guard<std::mutex> guard(bcube_global.mutex);
	bcube_global.tensor_table.emplace(name, std::move(e));
	bcube_global.message_queue.push(message);
}

// MPI must be initialized and the background thread must be running before
// this function is called.
void EnqueueTensorBroadcast(OpKernelContext* context, const Tensor& tensor,
                            Tensor* output, int root_rank,
                            GPU_EVENT_IF_CUDA ready_event,
                            const std::string name, const int device,
                            StatusCallback callback)
{
	MPIDataType dtype;
	Status status = DataTypeToMPIType(tensor.dtype(), &dtype);
	if (!status.ok())
	{
		callback(status);
		return;
	}

	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	MPIRequest message;
	message.set_request_rank(rank);
	message.set_tensor_name(name);
	message.set_tensor_type(dtype);
	message.set_root_rank(root_rank);
	message.set_device(device);
	message.set_request_type(MPIRequest::BROADCAST);
	for (int i = 0; i < tensor.shape().dims(); i++)
	{
		message.add_tensor_shape(tensor.shape().dim_size(i));
	}

	TensorTableEntry e;
	e.tensor_name = name;
	e.context = context;
	e.tensor = tensor;
	e.output = output;
	e.root_rank = root_rank;
	e.ready_event = ready_event;
	e.device = device;
	e.callback = callback;

	std::lock_guard<std::mutex> guard(bcube_global.mutex);
	bcube_global.tensor_table.emplace(name, std::move(e));
	bcube_global.message_queue.push(message);
}

int GetDeviceID(OpKernelContext* context)
{
	int device = CPU_DEVICE_ID;
	if (context->device() != nullptr &&
	        context->device()->tensorflow_gpu_device_info() != nullptr)
	{
		device = context->device()->tensorflow_gpu_device_info()->gpu_id;
	}
	return device;
}

// On GPU this event will signal that data is ready, and tensors are
// allocated.
GPU_EVENT_IF_CUDA RecordReadyEvent(OpKernelContext* context)
{
#if HAVE_CUDA
	auto device_context = context->op_device_context();
	if (device_context != nullptr)
	{
		auto executor = device_context->stream()->parent();
		GPU_EVENT_IF_CUDA ready_event = new perftools::gputools::Event(executor);
		ready_event->Init();
		device_context->stream()->ThenRecordEvent(ready_event);
		return ready_event;
	}
#endif
	return nullptr;
}

} // namespace tensorflow

class BcubeAllreduceOp : public AsyncOpKernel
{
public:
	explicit BcubeAllreduceOp(OpKernelConstruction* context)
		: AsyncOpKernel(context) {}

	void ComputeAsync(OpKernelContext* context, DoneCallback done) override
	{
		OP_REQUIRES_OK(context, CheckInitialized());

		auto node_name = name();
		auto device = GetDeviceID(context);
		auto tensor = context->input(0);
		Tensor* output;
		OP_REQUIRES_OK(context,
		               context->allocate_output(0, tensor.shape(), &output));
		GPU_EVENT_IF_CUDA ready_event = RecordReadyEvent(context);
		EnqueueTensorAllreduce(context, tensor, output, ready_event, node_name,
		                       device, [context, done](const Status & status)
		{
			context->SetStatus(status);
			done();
		});
	}
};

REGISTER_KERNEL_BUILDER(Name("BcubeAllreduce").Device(DEVICE_CPU),
                        BcubeAllreduceOp);
#if BCUBE_GPU_ALLREDUCE
REGISTER_KERNEL_BUILDER(Name("BcubeAllreduce").Device(DEVICE_GPU),
                        BcubeAllreduceOp);
#endif

REGISTER_OP("BcubeAllreduce")
.Attr("T: {int32, int64, float32, float64}")
.Input("tensor: T")
.Output("sum: T")
.SetShapeFn([](shape_inference::InferenceContext* c)
{
	c->set_output(0, c->input(0));
	return Status::OK();
})
.Doc(R"doc(
Perform an MPI Allreduce on a tensor. All other processes that do a reduction
on a tensor with the same name must have the same dimension for that tensor.
Tensors are reduced with other tensors that have the same node name for the
allreduce.

Arguments
    tensor:     A tensor to reduce.

Output
    sum:    A tensor with the same shape as `tensor`, summed across all MPI processes.
)doc");

class BcubeAllgatherOp : public AsyncOpKernel {
public:
  explicit BcubeAllgatherOp(OpKernelConstruction* context)
      : AsyncOpKernel(context) {}

  void ComputeAsync(OpKernelContext* context, DoneCallback done) override {
    OP_REQUIRES_OK(context, CheckInitialized());

    auto node_name = name();
    auto device = GetDeviceID(context);
    auto tensor = context->input(0);
    // We cannot pre-allocate output for allgather, since shape of result
    // is only known after all ranks make a request.
    GPU_EVENT_IF_CUDA ready_event = RecordReadyEvent(context);
    EnqueueTensorAllgather(context, tensor, ready_event, node_name, device,
                           [context, done](const Status& status) {
                             context->SetStatus(status);
                             done();
                           });
  }
}; // namespace tensorflow

REGISTER_KERNEL_BUILDER(Name("BcubeAllgather").Device(DEVICE_CPU),
                        BcubeAllgatherOp);
#if BCUBE_GPU_ALLGATHER
REGISTER_KERNEL_BUILDER(Name("BcubeAllgather").Device(DEVICE_GPU),
                        BcubeAllgatherOp);
#endif

REGISTER_OP("BcubeAllgather")
    .Attr("T: {uint8, int8, uint16, int16, int32, int64, float32, float64, bool}")
    .Input("tensor: T")
    .Output("output: T")
    .SetShapeFn([](shape_inference::InferenceContext* c) {
      shape_inference::ShapeHandle output;
      TF_RETURN_IF_ERROR(
          c->ReplaceDim(c->input(0), 0, c->UnknownDim(), &output));
      c->set_output(0, output);
      return Status::OK();
    })
    .Doc(R"doc(
Perform an MPI Allgather on a tensor. All other processes that do a gather on a
tensor with the same name must have the same rank for that tensor, and have the
same dimension on all but the first dimension.

Arguments
    tensor:     A tensor to gather.

Output
    gathered:    A tensor with the same shape as `tensor` except for the first dimension.
)doc");

class BcubeBroadcastOp : public AsyncOpKernel {
public:
  explicit BcubeBroadcastOp(OpKernelConstruction* context)
      : AsyncOpKernel(context) {
    OP_REQUIRES_OK(context, context->GetAttr("root_rank", &root_rank_));
  }

  void ComputeAsync(OpKernelContext* context, DoneCallback done) override {
    OP_REQUIRES_OK(context, CheckInitialized());

    auto node_name = name();
    auto device = GetDeviceID(context);
    auto tensor = context->input(0);
    Tensor* output = nullptr;
    if (bcube_global.rank == root_rank_) {
      context->set_output(0, tensor);
    } else {
      OP_REQUIRES_OK(context,
                     context->allocate_output(0, tensor.shape(), &output));
    }
    GPU_EVENT_IF_CUDA ready_event = RecordReadyEvent(context);
    EnqueueTensorBroadcast(context, tensor, output, root_rank_, ready_event,
                           node_name, device,
                           [context, done](const Status& status) {
                             context->SetStatus(status);
                             done();
                           });
  }

private:
  int root_rank_;
};

REGISTER_KERNEL_BUILDER(Name("BcubeBroadcast").Device(DEVICE_CPU),
                        BcubeBroadcastOp);
#if BCUBE_GPU_BROADCAST
REGISTER_KERNEL_BUILDER(Name("BcubeBroadcast").Device(DEVICE_GPU),
                        BcubeBroadcastOp);
#endif

REGISTER_OP("BcubeBroadcast")
    .Attr("T: {uint8, int8, uint16, int16, int32, int64, float32, float64, bool}")
    .Attr("root_rank: int")
    .Input("tensor: T")
    .Output("output: T")
    .SetShapeFn([](shape_inference::InferenceContext* c) {
      c->set_output(0, c->input(0));
      return Status::OK();
    })
    .Doc(R"doc(
Perform an MPI Broadcast on a tensor. All other processes that do a broadcast
on a tensor with the same name must have the same dimension for that tensor.

Arguments
    tensor:     A tensor to broadcast.
    root_rank:  Rank that will send data, other ranks will receive data.

Output
    output:    A tensor with the same shape as `tensor` and same value as
               `tensor` on root rank.
)doc");

} // namespace tensorflow
} // namespace bcube



#include <cstdio>
#include <iostream>
#include <vector>
#include "bcube_comm.h"
#include "bcube_ops.h"


/*
*socket asy
* http://blog.csdn.net/bian1029/article/details/72974505
*/


int main()
{
	
	bcube_ops_test();
	//bcube_test();
	return 0;
}

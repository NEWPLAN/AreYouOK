# BCube_Parameter_Syn
a parameter synchoralization in Bcube.
